//
//  LockStatus.swift
//  touchfeelygoodness
//
//  Created by Caleb Stultz on 9/28/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import Foundation

enum LockStatus {
    case locked
    case unlocked
}
